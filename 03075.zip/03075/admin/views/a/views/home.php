<div class="row">
  <div class="col-md-12">
    <h1>BUMI.</h1>
    <h3>Wilujeng Sumping <?=$_SESSION['nama']?></h3>
  </div>
</div>